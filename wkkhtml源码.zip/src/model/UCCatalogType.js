export const CatalogType={
    group:'group',
    item:'item',
    dataLabel:[
        {
            id: 0,
            label: "组",
            value: 'group'
        },
        {
            id: 1,
            label: "项",
            value: 'item'
        },
    ]
}