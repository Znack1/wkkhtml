/*
 * @Descripttion: 
 * @version: 1.0
 * @Author: zkc
 * @Date: 2021-05-24 15:26:48
 * @LastEditors: zkc
 * @LastEditTime: 2021-05-31 19:35:18
 * @input: no param
 * @out: no param
 */

export const UCOperationType =
{
    operation_add: "add",
    operation_update: "update",
    operation_delete: "delete",
    operation_preview: "preview"
}