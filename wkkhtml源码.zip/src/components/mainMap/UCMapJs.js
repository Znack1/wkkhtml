/*
 * @Description: In User Settings Edit
 * @Author: your name
 * @Date: 2019-07-09 11:37:13
 * @LastEditTime: 2022-11-18 15:29:28
 * @LastEditors: zkc
 */
export const UCMapEvent = {

    UCMap_event_zoomlevelChange: "UCMap_event_zoomlevelChange",
    UCMap_event_drawFinish: "ucMap_event_drawFinish", // 画完订阅
    UCOverlay_event_canel: "UCOverlay_event_canel",

}