/*
 * @Descripttion: 
 * @version: 
 * @Author: zkc
 * @Date: 2020-03-11 10:07:46
 * @LastEditors: zkc
 * @LastEditTime: 2022-07-27 11:38:32
 */

export const UCBaseLayerSwitchEvent = {

    UCBaseLayerSwitch_vector_click: "event_UCBaseLayerSwitch_vector_click",

    UCBaseLayerSwitch_image_click: "event_UCBaseLayerSwitch_image_click",

    UCBaseLayerSwitch_ter_click: "event_UCBaseLayerSwitch_ter_click",

    UCBaseLayerSwitch_reset_click: "UCBaseLayerSwitch_reset_click",

    UCBaseLayerSwitch_tagList_click: "UCBaseLayerSwitch_tagList_click",

    controlLayer_change_status: "controlLayer_change_status",

    UCBaseLayerSwitch_showOverlappingLayer_click: "UCBaseLayerSwitch_showOverlappingLayer_click",

    UCBaseLayerSwitchEvent__mapToolCm:"UCBaseLayerSwitchEvent__mapToolCm", // 测面
    UCBaseLayerSwitchEvent__mapToolCj: "UCBaseLayerSwitchEvent__mapToolCj", // 测距



}