/*
 * @Description: In User Settings Edit
 * @Author: your name
 * @Date: 2019-08-26 20:22:34
 * @LastEditTime: 2019-08-26 21:18:20
 * @LastEditors: Please set LastEditors
 */

export const UCZoomControlEvent =
{
    UCZoomControl_event_showLegend: "UCZoomControl_event_showLegend",

    UCZoomControl_event_zoomInClick: "UCZoomControl_event_zoomInClick",

    UCZoomControl_event_zoomOutClick: "UCZoomControl_event_zoomOutClick",




}