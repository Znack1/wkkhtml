/*
 * @Descripttion: 
 * @version: 1.0
 * @Author: zkc
 * @Date: 2021-06-10 11:58:43
 * @LastEditors: zkc
 * @LastEditTime: 2021-09-28 17:44:16
 * @input: no param
 * @out: no param
 */
export const EventManageCode ={
    "treeNodeClick":"tree_node_click",
    "treeCheckChange":"check-change",
    "treeNodeNameClick":"tree-node-name-click",
    "treeNodeNameDbClick": "node-name-db-click",
    "treeNodeEdit": "node-edit",
    "district_change":"district_change",


    "letMenuTreeCheckChange":"letMenuTreeCheckChange",
    
    "importFile_changeType":"importFile_changeType",
    "importFile_changeFile":"import_changeFile",

    "importShp_change": 'importShp_change',


    "common_event_coordinate_drawRact": 'drawRact',
    "common_event_coordinate_clear": 'clear',
  
    "common_event_reset_clear": 'resetClear',

    // 下拉框树结构
    "selectTree_checked_change":"change"

}