export class DialogSystemJs
{

}
DialogSystemJs.ucOpenDialog = null;